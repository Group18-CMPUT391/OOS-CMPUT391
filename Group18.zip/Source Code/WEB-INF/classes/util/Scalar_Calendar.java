package util;
import java.util.*;
import java.io.*;
import java.sql.*;

import oracle.sql.*;
import oracle.jdbc.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;
import 
import net.coobird.thumbnailator.*;

public Scalar_Calendar{
		private GregorianCalendar;
		public ResultSet set_Years(String selected_year){
			Db db=new Db();
			db_connect_db();
			GregorianCalendar.set(Int.valueOf(selected_string),01,01);
			
		}
}
