import java.util.*;
import java.io.*;
import java.sql.*;

import oracle.sql.*;
import oracle.jdbc.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;

import net.coobird.thumbnailator.*;

Public Scalar_Week{
}
