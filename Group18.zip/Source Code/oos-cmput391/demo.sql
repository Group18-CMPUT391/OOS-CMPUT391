INSERT INTO persons Values('1', 'Huy', 'Truong', '11008 88 ave, Edmonton, T6G0Z2', 'huy@oos.ca', '0123456789');
INSERT INTO users Values('huy', 'huy', 'a', '1', '20-Nov-15');

INSERT INTO persons Values('2', 'Wayne', 'Choi', 'University of Alberta', 'wayne@oos.ca', '1123456789');
INSERT INTO users Values('wayne', 'wayne', 's', '2', '21-Nov-15');

INSERT INTO persons Values('3', 'Akram', 'Hassen', 'Castle Down, Alberta', 'akram@oos.ca', '2123456789');
INSERT INTO users Values('akram', 'akram', 'd', '3', '22-Nov-15');
